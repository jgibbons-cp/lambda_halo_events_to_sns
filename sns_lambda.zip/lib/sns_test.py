import json
import os
import boto3

class SNS_Test(object):

    def __init__(self):
        pass

    # Send Halo events to the SNS
    def send_notification(self, event):
        FIRST = 0

        # get the SQS endpoint
        queue_url = os.getenv("SQS_URL")
        resource_type = 'sqs'
        self.client = boto3.client(resource_type)

        event_s = json.dumps(event)

        messages = self.get_last_event_timestamp(queue_url)

        try:
            self.delete_message(queue_url,
                                messages["Messages"][FIRST]["ReceiptHandle"])
        except KeyError:
            pass

        self.last_time_stamp_to_sqs(event, queue_url)

        arn = os.getenv("SNS_ARN")
        sns = boto3.resource('sns')
        topic = sns.Topic(arn)

        response = topic.publish(
            Message=event_s,
            Subject="Halo Security Event",
        )

    def last_time_stamp_to_sqs(self, event, queue_url):
        response = self.client.send_message(
            QueueUrl=queue_url,
            MessageBody=event["created_at"],
            MessageGroupId='last_event_timestamp'
        )

        print "Last timestamp %s\n" % event["created_at"]

    def delete_message(self, queue_url, receipt_handle):
        self.client.delete_message(
            QueueUrl=queue_url,
            ReceiptHandle=receipt_handle
        )

    def get_last_event_timestamp(self, queue_url):
        messages = self.client.receive_message(
            QueueUrl=queue_url,
            AttributeNames=[
                'All'
            ],
            MessageAttributeNames=[
                'string',
            ],
            MaxNumberOfMessages=1,
            # VisibilityTimeout=123,
            WaitTimeSeconds=20,
            # ReceiveRequestAttemptId='string'
        )

        return messages